/**
    * f(x) = 2.5x^3 + (49/17)x^2 - 15 is the function.
    * Calculate the function with the given x.
    * @version      1.0
    * @author       Charlotte Zeeb -- FSZ 52
*/

// Import of the java utility "Scanner".
import java.util.Scanner;

// Declaration of the public class $CLASS.
public class Rechner {

// Main function being called up.
    public static void main(String[] args) {

// Function "Scanner" being created.
        Scanner scanfkt = new Scanner(System.in);

// Define variable values.
        double a = 2.5;
        double b = (49/17);
        double c = 15;

// Gather information.
        System.out.println("Please enter x: ");
        double z01 = scanfkt.nextDouble();

// Declare the math.
        // 2.5x^3
        double findx01 = a * (z01 * z01 * z01);
        // (49/17)x^2
        double findx02 = b * (z01 * z01);
        // 2.5x^3 + (49/17)x^2 - 15 (full function).
        double findx03 = findx01 + findx02 - c;

// Print the results.
        System.out.println("The final result is: "+findx03);

// Main function being closed.
    }

// Declaration being closed.
}
